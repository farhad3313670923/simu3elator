Simu3elator Pro EEE — Vercel deployment bundle

This directory contains the application as index.html and its Vercel headers config.

Deploy from a terminal with Vercel CLI:
  npm i -g vercel
  cd simu3elator-vercel
  vercel login
  vercel --prod

After deployment, in Supabase Dashboard → Authentication → URL Configuration:
1) Set Site URL to the production Vercel URL.
2) Add the production Vercel URL and its /** wildcard to Redirect URLs.

The app uses Supabase Auth REST endpoints. It does not require a service_role key.
